{{-- resources/views/setoran/nasabah-detail.blade.php --}}
<x-layouts.app title="Setoran Saya">
    <div class="relative mb-6 w-full">
        <flux:heading size="xl" level="1">Riwayat Setoran Anggota</flux:heading>
        <flux:separator variant="subtle" />
    </div>

    @livewire('nasabah-detail')
</x-layouts.app>

