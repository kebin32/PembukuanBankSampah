<x-layouts.app title="Kas">
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
        <h1> Buku KAS bank sampah</h1>
    <livewire:kas-component >
    </div>

</x-layouts.app>
