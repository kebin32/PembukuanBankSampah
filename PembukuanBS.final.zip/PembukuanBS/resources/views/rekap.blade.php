<x-layouts.app title="Rekap">
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
        <h1> Rekap bulanan</h1>
        <livewire:rekap-create />
    </div>
    
</x-layouts.app>