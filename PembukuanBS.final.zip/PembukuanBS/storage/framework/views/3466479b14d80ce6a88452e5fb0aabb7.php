
<div class="p-6 space-y-4">
    <div class="mb-4">
        <label for="user_id" class="block text-sm font-medium text-gray-700 mb-1">Pilih Nasabah</label>
        <select wire:model="user_id" id="user_id" class="w-full border-gray-300 rounded-md shadow-sm focus:ring focus:ring-blue-200">
            <option value="">-- Pilih Nasabah --</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </select>
    </div>
    <button wire:click="$refresh" class="mb-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition">
        Update Data
    </button>

    <div class="overflow-x-auto">
        <table class="w-full table-auto border rounded-md shadow-sm">
            <thead class="bg-gray-100">
                <tr class="text-left text-gray-700">
                    <th class="p-2">Tanggal</th>
                    <th class="p-2">Jenis Sampah</th>
                    <th class="p-2">Harga/kg</th>
                    <th class="p-2">Berat (kg)</th>
                    <th class="p-2">Total</th>
                </tr>
            </thead>
            <tbody class="text-gray-600">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $setoranDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-t">
                        <td class="p-2"><?php echo e($detail->created_at->format('d-m-Y H:i:s')); ?></td>
                        <td class="p-2"><?php echo e($detail->daftar->nama ?? '-'); ?></td>
                        <td class="p-2">Rp <?php echo e(number_format($detail->harga, 0, ',', '.')); ?></td>
                        <td class="p-2"><?php echo e($detail->satuan); ?></td>
                        <td class="p-2" style="text-align: right !important;"">Rp <?php echo e(number_format($detail->total, 0, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-gray-400 py-4">Tidak ada data setoran.</td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    
    <div class="mt-4">
        <?php echo e($setoranDetails->links()); ?>

    </div>
</div>

<?php /**PATH C:\Users\UMA\Herd\PembukuanBS\resources\views/livewire/nasabah-detail.blade.php ENDPATH**/ ?>