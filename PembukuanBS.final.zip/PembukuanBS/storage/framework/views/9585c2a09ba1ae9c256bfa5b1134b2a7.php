
<!DOCTYPE html>
<html>
<head>
    <title>Rekap Transaksi PDF</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid #333; padding: 4px 8px; }
        th { background: #eee; }
    </style>
</head>
<body>
    <h2>Rekap Transaksi Bulan <?php echo e($bulan); ?>/<?php echo e($tahun); ?></h2>
    <p>Jenis Rekap: <?php echo e(ucfirst($jenisRekap)); ?></p>

    <?php if($jenisRekap === 'setoran' || $jenisRekap === 'semua'): ?>
    <h3>Setoran Sampah</h3>
    <table>
        <thead>
            <tr>
                <th>Nama Nasabah</th>
                <th>Tanggal</th>
                <th>Jenis Sampah</th>
                <th>Berat (kg)</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $setoranDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($detail->user->name ?? '-'); ?></td>
                <td><?php echo e($detail->tanggal_transaksi ? \Carbon\Carbon::parse($detail->tanggal_transaksi)->format('d-m-Y') : '-'); ?></td>
                <td><?php echo e($detail->daftar->nama ?? '-'); ?></td>
                <td><?php echo e($detail->satuan); ?></td>
                <td>Rp <?php echo e(number_format($detail->subtotal, 0, ',', '.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>

    <?php if($jenisRekap === 'kas' || $jenisRekap === 'semua'): ?>
    <h3>Transaksi Kas</h3>
    <table>
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nasabah</th>
                <th>Aksi</th>
                <th>Nominal</th>
                <th>Saldo</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kasRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($kas->tanggal); ?></td>
                <td><?php echo e($kas->user->name ?? '-'); ?></td>
                <td><?php echo e(ucfirst($kas->aksi)); ?></td>
                <td>Rp <?php echo e(number_format($kas->nominal, 0, ',', '.')); ?></td>
                <td>Rp <?php echo e(number_format($kas->saldo, 0, ',', '.')); ?></td>
                <td><?php echo e($kas->keterangan); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\UMA\Herd\samp.kas.fix\resources\views/prints/rekap-transaksi-pdf.blade.php ENDPATH**/ ?>