<div class="max-w-3xl mx-auto bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md">
    <h2 class="text-2xl font-bold text-gray-700 dark:text-white mb-4">Tambah Setoran</h2>

    <form wire:submit.prevent="submit">
        <div class="mb-4">
            <label class="block text-gray-600 dark:text-gray-200 text-sm font-semibold mb-1">Nasabah</label>
            <select wire:model="nasabah_id" class="w-full p-2 border border-gray-400 dark:border-gray-500 rounded-lg bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring focus:ring-blue-300" style="color: inherit;">
                <option value="">Pilih Nasabah</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $nasabahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nasabah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($nasabah->id); ?>"><?php echo e($nasabah->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nasabah_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        <div class="mb-4">
            <label class="block text-gray-600 dark:text-gray-200 text-sm font-semibold mb-1">Tanggal</label>
            <input type="date" wire:model="tanggal" class="w-full p-2 border border-gray-400 dark:border-gray-500 rounded-lg bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring focus:ring-blue-300">
        </div>

        <div class="overflow-x-auto">
            <table class="w-full border-collapse border text-sm">
                <thead class="bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 uppercase">
                    <tr>
                        <th class="p-2 border">Daftar Harga</th>
                        <th class="p-2 border">Satuan (kg)</th>
                        <th class="p-2 border">Harga</th>
                        <th class="p-2 border">Subtotal</th>
                        <th class="p-2 border">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="p-2 border">
                            <select wire:model="details.<?php echo e($index); ?>.daftar_id" class="w-full p-2 border border-gray-400 dark:border-gray-500 rounded-lg bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring focus:ring-blue-300">
                                <option value="">Pilih Barang</option>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $daftars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daftar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($daftar->id); ?>"><?php echo e($daftar->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </select>
                        </td>
                        <td class="p-2 border">
                            <input type="number" wire:model="details.<?php echo e($index); ?>.satuan" min="1" class="w-full p-2 border border-gray-400 dark:border-gray-500 rounded-lg bg-white dark:bg-gray-900 text-gray-900 dark:text-white focus:ring focus:ring-blue-300">
                        </td>
                        <td class="p-2 border text-center text-gray-900 dark:text-gray-200"><?php echo e(number_format($details[$index]['harga'] ?? 0)); ?></td>
                        <td class="p-2 border text-center text-gray-900 dark:text-gray-200"><?php echo e(number_format($details[$index]['subtotal'] ?? 0)); ?></td>
                        <td class="p-2 border text-center">
                            <button type="button" wire:click="removeDetail(<?php echo e($index); ?>)" class="text-red-500 hover:text-red-700">Hapus</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            <button type="button" wire:click="addDetail" class="px-4 py-2 bg-green-500 dark:bg-green-600 text-white rounded-lg hover:bg-green-600 dark:hover:bg-green-700 transition">Tambah Barang</button>
        </div>

        <div class="mt-4 p-4 bg-gray-100 dark:bg-gray-700 rounded-lg">
            <h3 class="text-xl font-semibold text-gray-700 dark:text-white">Total: Rp <?php echo e(number_format($total)); ?></h3>
        </div>

        <div class="mt-6">
            <button type="submit" class="w-full px-4 py-2 bg-blue-500 dark:bg-blue-600 text-white rounded-lg hover:bg-blue-600 dark:hover:bg-blue-700 transition">Simpan</button>
        </div>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
    </form>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('success')): ?>
        <div class="mt-4 p-3 bg-green-100 dark:bg-green-800 text-green-700 dark:text-green-300 border border-green-400 dark:border-green-600 rounded-lg">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>

<?php /**PATH C:\Users\UMA\Herd\samp\resources\views/livewire/setoran-create.blade.php ENDPATH**/ ?>