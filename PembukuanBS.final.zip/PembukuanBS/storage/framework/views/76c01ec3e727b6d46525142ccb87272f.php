<div class="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-md">
    <h2 class="text-2xl font-bold mb-6 text-gray-700">Rekap Transaksi Bulanan</h2>

    <div class="flex flex-wrap -mx-2 mb-6">
        <div class="w-full md:w-1/2 px-2 mb-4 md:mb-0">
            <select wire:model="bulan" class="border rounded p-2 text-gray-700 w-full">
                <!--[if BLOCK]><![endif]--><?php for($i = 1; $i <= 12; $i++): ?>
                    <option value="<?php echo e(str_pad($i, 2, '0', STR_PAD_LEFT)); ?>">Bulan <?php echo e($i); ?></option>
                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>

        <div class="w-full md:w-1/2 px-2">
            <select wire:model="tahun" class="border rounded p-2 text-gray-700 w-full">
                <!--[if BLOCK]><![endif]--><?php for($i = date('Y') - 5; $i <= date('Y'); $i++): ?>
                    <option value="<?php echo e($i); ?>">Tahun <?php echo e($i); ?></option>
                <?php endfor; ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
    </div>

    <div class="mb-6">
        <h3 class="text-xl font-semibold mb-2 text-gray-600">Setoran</h3>
        <table class="w-full border rounded-lg shadow-md">
            <thead>
                <tr class="bg-gray-200 text-gray-700">
                    <th class="p-2">Tanggal</th>
                    <th class="p-2">Nasabah</th>
                    <th class="p-2">Daftar Harga</th>
                    <th class="p-2">Harga/kg</th>
                    <th class="p-2">Total</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $setoranRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setoran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t text-gray-600">
                        <td class="p-2"><?php echo e($setoran->tanggal); ?></td>
                        <td class="p-2"><?php echo e($setoran->nasabah->nama); ?></td>
                        <td class="p-2">
                            <ul>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $setoran->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($detail->harga->nama ?? '-'); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </td>
                        <td class="p-2">
                            <ul>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $setoran->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>Rp <?php echo e(number_format($detail->harga->harga_kg ?? 0, 2, ',', '.')); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </ul>
                        </td>
                        <td class="p-2">Rp <?php echo e(number_format($setoran->total, 2, ',', '.')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    <div>
        <h3 class="text-xl font-semibold mb-2 text-gray-600">Kas</h3>
        <table class="w-full border-collapse border border-gray-300">
            <thead>
                <tr class="bg-blue-100 text-gray-700">
                    <th class="border p-2">Tanggal</th>
                    <th class="border p-2">Nasabah</th>
                    <th class="border p-2">Aksi</th>
                    <th class="border p-2">Nominal</th>
                    <th class="border p-2">Saldo</th>
                    <th class="border p-2">Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $kasRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="text-gray-600">
                        <td class="border p-2"><?php echo e($kas->tanggal); ?></td>
                        <td class="border p-2"><?php echo e($kas->nasabah->nama); ?></td>
                        <td class="border p-2"><?php echo e(ucfirst($kas->aksi)); ?></td>
                        <td class="border p-2">Rp<?php echo e(number_format($kas->nominal, 2, ',', '.')); ?></td>
                        <td class="border p-2">Rp<?php echo e(number_format($kas->saldo, 2, ',', '.')); ?></td>
                        <td class="border p-2"><?php echo e($kas->keterangan); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>    

    <button wire:click="exportPDF" class="mt-6 bg-blue-600 text-grey p-3 rounded-lg">Export PDF</button>
</div>

<?php /**PATH C:\Users\UMA\Herd\samp\resources\views/livewire/rekap-create.blade.php ENDPATH**/ ?>