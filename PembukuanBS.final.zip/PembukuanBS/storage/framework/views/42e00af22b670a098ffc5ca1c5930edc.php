<div <?php echo e($attributes->class('flex-1')); ?> data-flux-spacer></div>
<?php /**PATH C:\Users\UMA\Herd\samp\vendor\livewire\flux\src/../stubs/resources/views/flux/spacer.blade.php ENDPATH**/ ?>