<div class="p-6 space-y-4">
    <h2 class="text-2xl font-bold text-gray-700 mb-4">Riwayat Setoran <?php echo e(auth()->user()->name); ?>!</h2>

    <!--[if BLOCK]><![endif]--><?php if($setoranDetails->isEmpty()): ?>
        <div class="text-gray-500">Belum ada data setoran.</div>
    <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full table-auto border rounded-md shadow-sm">
                <thead class="bg-gray-100">
                    <tr class="text-left text-gray-700">
                        <th class="p-2">Tanggal</th>
                        <th class="p-2">Jenis Sampah</th>
                        <th class="p-2">Harga/kg</th>
                        <th class="p-2">Berat (kg)</th>
                        <th class="p-2">Total</th>
                    </tr>
                </thead>
                <tbody class="text-gray-600">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $setoranDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t">
                            <td class="p-2"><?php echo e($detail->created_at->format('d-m-Y H:i:s')); ?></td>
                            <td class="p-2"><?php echo e($detail->daftar->nama ?? '-'); ?></td>
                            <td class="p-2">Rp <?php echo e(number_format($detail->harga, 0, ',', '.')); ?></td>
                            <td class="p-2"><?php echo e($detail->satuan); ?></td>
                            <td class="p-2">Rp <?php echo e(number_format($detail->total, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>

        
        <div class="mt-4">
            <?php echo e($setoranDetails->links()); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>

<?php /**PATH C:\Users\UMA\Herd\samp\resources\views/livewire/nasabah-detail.blade.php ENDPATH**/ ?>