<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Dashboard']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Dashboard']); ?>
    <div class="flex h-full w-full flex-1 flex-col gap-4 rounded-xl">
        <div class="grid auto-rows-min gap-4 md:grid-cols-3">
            
            <!-- Kartu Saldo Bank Sampah -->
            <div class="p-4 bg-white rounded shadow dark:bg-gray-800">
                <h2 class="text-lg font-semibold text-gray-900 dark:text-white">
                    Selamat datang, <?php echo e(auth()->user()->name); ?>!
                </h2>
                <p class="text-sm text-gray-700 dark:text-gray-300">
                    Role: <strong class="text-gray-800 dark:text-gray-100"><?php echo e(auth()->user()->role); ?></strong>
                </p>
                <p class="text-sm text-gray-700 dark:text-gray-300">
                    Saldo: <strong class="text-gray-800 dark:text-gray-100">Rp <?php echo e(number_format(auth()->user()->saldo, 0, ',', '.')); ?></strong>
                </p>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>

<?php /**PATH C:\Users\UMA\Herd\samp.kas.fix\resources\views/dashboard.blade.php ENDPATH**/ ?>